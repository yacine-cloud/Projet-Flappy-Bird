#ifndef MAIN_H
#define	MAIN_H

static unsigned char usbReadBuffer[32];
static unsigned char usbWriteBuffer[32];

#endif	/* MAIN_H */

