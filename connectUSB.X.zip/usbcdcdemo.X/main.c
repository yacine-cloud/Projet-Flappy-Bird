#include <xc.h>
#include "sysconfig.h"
#include "usb_cdc_lib.h"
#include "main.h"

// D�finition des ports
#define LED LATCbits.LATC0
#define BUTTON PORTDbits.RD0

// Prototypes
void debounceDelay(void);
void sendFlap(void);

void main(void) {
    // Initialisation des ports
    TRISC = 0x00;    // Port C en sortie
    LATC = 0x00;     // LEDs �teintes
    TRISDbits.TRISD0 = 1; // Bouton en entr�e

    // Initialisation USB
    initUSBLib();

    while(1) {
        USBDeviceTasks();  // G�rer les t�ches USB

        // Si USB est pr�t
        if (isUSBReady()) {
            if (BUTTON) {
                LED = 1;       // Allume LED
                sendFlap();    // Envoie le mot "flap"
                debounceDelay();
                while(BUTTON); // Attente rel�chement
                LED = 0;       // �teint LED
            }
        }
    }
}

// Fonction qui envoie "flap\r\n" via USB
void sendFlap(void) {
    char msg[] = "flap\r\n";
    putUSBUSART((uint8_t*)msg, sizeof(msg)-1);
    CDCTxService(); // S'assurer que les donn�es sont transmises
}

// Simple d�lai anti-rebond
void debounceDelay(void) {
    for (volatile int i=0; i<255; i++)
        for (volatile int j=0; j<255; j++);
}

// Interruption USB (optionnelle, selon stack)
void __interrupt() mainISR(void) {
    processUSBTasks();
}
